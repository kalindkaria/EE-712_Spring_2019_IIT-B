
extern int gen_twiddle_fft16x16 (
    short *w,
    int n
);

