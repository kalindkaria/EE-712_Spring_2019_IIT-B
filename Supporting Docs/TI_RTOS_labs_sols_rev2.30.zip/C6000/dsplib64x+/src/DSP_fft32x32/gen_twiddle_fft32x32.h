
extern int gen_twiddle_fft32x32 (
    int *w,
    int n,
    double scale
);

