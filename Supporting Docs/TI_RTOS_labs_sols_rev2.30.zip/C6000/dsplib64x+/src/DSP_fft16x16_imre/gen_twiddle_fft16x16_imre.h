
extern int gen_twiddle_fft16x16_imre (
    short *w,
    int n
);

