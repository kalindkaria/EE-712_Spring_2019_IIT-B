
extern int gen_twiddle_ifft16x16 (
    short *w,
    int n
);

