
extern int gen_twiddle_fft16x32 (
    short *w,
    int n
);

